using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class board_Transforms : MonoBehaviour
{
    public GameObject circle1;
    public GameObject circle2;
    public float IC_HP = 0;
    public float IC_HN = 0;
    public float IC_MP = 0;
    public float IC_MN = 0;
    public InputField IC_HP_Text;
    public InputField IC_HN_Text;
    public InputField IC_MP_Text;
    public InputField IC_MN_Text;
    public float angle;
    public float angle_2;
    public float OC_HP = 0;
    public float OC_HN = 0;
    public float OC_MP = 0;
    public float OC_MN = 0;
    public InputField OC_HP_Text;
    public InputField OC_HN_Text;
    public InputField OC_MP_Text;
    public InputField OC_MN_Text;
    public Text randomRollText;
    public int randomRoll = 500;
    public float OC_H = 0;
    public float OC_M = 0;
    public float IC_H = 0;
    public float IC_M = 0;
    public Text IC_Hour;
    public Text IC_Minute;
    public Text OC_Hour;
    public Text OC_Minute;
    
    public float total_roation;

    public Button rollDice;
    public Button IC_CC_H;
    public Button IC_C_H;
    public Button IC_CC_M;
    public Button IC_C_M;
    public Button OC_CC_H;
    public Button OC_C_H;
    public Button OC_CC_M;
    public Button OC_C_M;
    public Button rotate;

    public void Update()
    {
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            if(IC_H >= 0)
            {
                IC_C_H.interactable = false;
            }
            if (IC_H <= 0)
            {
                IC_CC_H.interactable = false;
            }
            if (IC_M >= 0)
            {
                IC_C_M.interactable = false;
            }
            if (IC_M <= 0)
            {
                IC_CC_M.interactable = false;
            }
            if (OC_H >= 0)
            {
                OC_C_H.interactable = false;
            }
            if (OC_H <= 0)
            {
                OC_CC_H.interactable = false;
            }
            if (OC_M >= 0)
            {
                OC_C_M.interactable = false;
            }
            if (OC_M <= 0)
            {
                OC_CC_M.interactable = false;
            }
        }
        else
        {
            IC_C_H.interactable = true;
            IC_CC_H.interactable = true;
            IC_C_M.interactable = true;
            IC_CC_M.interactable = true;
            OC_C_H.interactable = true;
            OC_CC_H.interactable = true;
            OC_C_M.interactable = true;
            OC_CC_M.interactable = true;
            rotate.interactable = false;
        }

    }

    public void OnDiceRollButton()
    {
        randomRoll = Random.Range(1, 7);
        randomRollText.text = randomRoll.ToString();
        rollDice.interactable = false;
    }

    public void OnCC_Rotation_IC_Hour()
    {
        IC_HN = IC_HN + 1;
        IC_H = IC_HP - IC_HN;
        IC_Hour.text = Mathf.Abs(IC_H).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnCC_Rotation_IC_Minute()
    {
        IC_MN += 1;
        IC_M = IC_MP - IC_MN;
        IC_Minute.text = Mathf.Abs(IC_M).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnC_Rotation_IC_Hour()
    {
        IC_HP += 1;
        IC_H = IC_HP - IC_HN;
        IC_Hour.text = Mathf.Abs(IC_H).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnC_Rotation_IC_Minute()
    {
        IC_MP += 1;
        IC_M = IC_MP - IC_MN;
        IC_Minute.text = Mathf.Abs(IC_M).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnCC_Rotation_OC_Hour()
    {
        OC_HN += 1;
        OC_H = OC_HP - OC_HN;
        OC_Hour.text = Mathf.Abs(OC_H).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnCC_Rotation_OC_Minute()
    {
        OC_MN += 1;
        OC_M = OC_MP - OC_MN;
        OC_Minute.text = Mathf.Abs(OC_M).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnC_Rotation_OC_Hour()
    {
        OC_HP += 1;
        OC_H = OC_HP - OC_HN;
        OC_Hour.text = Mathf.Abs(OC_H).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnC_Rotation_OC_Minute()
    {
        OC_MP += 1;
        OC_M = OC_MP - OC_MN;
        OC_Minute.text = Mathf.Abs(OC_M).ToString();
        if (randomRoll == Mathf.Abs(IC_H) + Mathf.Abs(IC_M) + Mathf.Abs(OC_H) + Mathf.Abs(OC_M))
        {
            rotate.interactable = true;
        }
    }

    public void OnRotateButtonPush()
    {
        ////Inner circle Hours Positive converting text to number


        ////if Inner circle Hours Positive textbox is nothing set default to 0


        angle = (IC_HP + IC_HN + IC_MP + IC_MN) * 6;

        circle1.transform.Rotate(0.0f, angle, 0.0f, Space.World);

        //outer circle starts here

        ////Inner circle Hours Positive converting text to number


        ////if Inner circle Hours Positive textbox is nothing set default to 0



        angle_2 = (OC_HP + OC_HN + OC_MP + OC_MN) * 6;

        circle2.transform.Rotate(0.0f, angle_2, 0.0f, Space.World);

        IC_C_H.interactable = false;
        IC_CC_H.interactable = false;
        IC_C_M.interactable = false;
        IC_CC_M.interactable = false;
        OC_C_H.interactable = false;
        OC_CC_H.interactable = false;
        OC_C_M.interactable = false;
        OC_CC_M.interactable = false;
        rotate.interactable = false;
    }

}
